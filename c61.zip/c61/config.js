import firebase from 'firebase';

var firebaseConfig = {
  apiKey: 'AIzaSyBwFXfCFe0gM6j1DONA6iujIHR3kqf97oE',
  authDomain: 'wireless-buzzer-appp-946aa.firebaseapp.com',
  databaseURL: 'https://wireless-buzzer-appp-946aa-default-rtdb.firebaseio.com',
  projectId: 'wireless-buzzer-appp-946aa',
  storageBucket: 'wireless-buzzer-appp-946aa.appspot.com',
  messagingSenderId: '343101070052',
  appId: '1:343101070052:web:20a1e4454222ae59a32af1',
  measurementId: 'G-349CSKG242',
};

// Initialize Firebase
//if(!firebase.apps.length){
firebase.initializeApp(firebaseConfig);
//}

export default firebase.database();
